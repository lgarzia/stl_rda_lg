import typer

app = typer.Typer()


@app.callback()  ##not sure what this does yet
def callback():
    """
    Package built to explore STL Data Region Alliance Data
    """


@app.command()
def run():
    """ Calls the streamlit application"""
    typer.echo("test command")

# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['stl_rda_lg', 'stl_rda_lg.strlit']

package_data = \
{'': ['*']}

install_requires = \
['mypy>=0.812,<0.813', 'streamlit>=0.79.0,<0.80.0', 'typer[all]>=0.3.2,<0.4.0']

setup_kwargs = {
    'name': 'stl-rda-lg',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Basic Read Me at this point\n',
    'author': 'Luke Garzia',
    'author_email': 'lgarzia@yahoo.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
